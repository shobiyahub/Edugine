from config import USE_LOCAL_EXPLAINER, LOCAL_EXPLAINER_MODEL
from ai_service import generate_text

_local_pipeline = None


def _local_explain(topic: str) -> str:
    global _local_pipeline
    if _local_pipeline is None:
        try:
            from transformers import pipeline
        except ImportError as exc:
            raise RuntimeError(
                "Local explainer dependencies are not installed. "
                "Use USE_LOCAL_EXPLAINER=false or install requirements-local.txt."
            ) from exc
        _local_pipeline = pipeline(
            "text2text-generation",
            model=LOCAL_EXPLAINER_MODEL,
        )

    prompt = (
        "Explain this topic to a beginner in simple language with a definition "
        "and one example: " + topic
    )
    result = _local_pipeline(prompt, max_new_tokens=220, do_sample=False)
    return result[0]["generated_text"].strip()


def explain_topic(topic: str) -> str:
    if USE_LOCAL_EXPLAINER:
        try:
            return _local_explain(topic)
        except Exception:
            # Cloud Gemini remains the reliable fallback if the optional local
            # model is unavailable on the current machine.
            pass

    prompt = f"""
Explain the following educational topic for a beginner:

Topic:
{topic}

Format:
1. Simple definition
2. How it works / key idea
3. One easy example
4. Three important points

Keep it concise and easy to revise.
"""
    return generate_text(prompt, max_output_tokens=1000)
