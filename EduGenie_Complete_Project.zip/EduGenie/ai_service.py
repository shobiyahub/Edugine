import json
from typing import Any

from config import GEMINI_API_KEY, GEMINI_MODEL, MOCK_AI

_client = None


def _get_client():
    global _client
    if _client is None:
        if not GEMINI_API_KEY:
            raise RuntimeError(
                "GEMINI_API_KEY is not configured. Add it to .env or set MOCK_AI=true."
            )
        try:
            from google import genai
        except ImportError as exc:
            raise RuntimeError(
                "google-genai is not installed. Run: pip install -r requirements.txt"
            ) from exc
        _client = genai.Client(api_key=GEMINI_API_KEY)
    return _client


def generate_text(prompt: str, system_instruction: str | None = None,
                  temperature: float = 0.4, max_output_tokens: int = 1200) -> str:
    if MOCK_AI:
        return "MOCK_AI response: " + prompt[:500]

    from google.genai import types

    client = _get_client()
    config = types.GenerateContentConfig(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        system_instruction=system_instruction or (
            "You are EduGenie, a helpful educational assistant. "
            "Be accurate, concise, age-appropriate and easy to understand."
        ),
    )
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=config,
    )
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()


def generate_json(prompt: str, schema: Any,
                  system_instruction: str | None = None) -> Any:
    if MOCK_AI:
        return [
            {
                "question": "What is the main idea of the supplied topic?",
                "options": ["Option A", "Option B", "Option C", "Option D"],
                "correct_answer": "Option A",
                "explanation": "This is a mock answer used for local testing."
            }
            for _ in range(3)
        ]

    from google.genai import types

    client = _get_client()
    config = types.GenerateContentConfig(
        temperature=0.2,
        max_output_tokens=1800,
        response_mime_type="application/json",
        response_schema=schema,
        system_instruction=system_instruction or (
            "You are EduGenie, an educational assistant. Return only valid structured data."
        ),
    )
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=config,
    )
    raw = getattr(response, "text", None)
    if not raw:
        raise RuntimeError("Gemini returned an empty JSON response.")
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("Gemini returned invalid JSON.") from exc
