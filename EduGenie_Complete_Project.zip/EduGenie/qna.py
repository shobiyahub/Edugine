from ai_service import generate_text


def answer_question(question: str) -> str:
    prompt = f"""
Answer this academic/general knowledge question for a student:

Question:
{question}

Requirements:
- Give the direct answer first.
- Then give a short explanation.
- Use simple language.
- If the question is ambiguous, state the assumption.
- Do not invent facts.
"""
    return generate_text(prompt, max_output_tokens=800)
