const task = document.getElementById("task");
const input = document.getElementById("userInput");
const inputLabel = document.getElementById("inputLabel");
const extraFields = document.getElementById("extraFields");
const submitBtn = document.getElementById("submitBtn");
const result = document.getElementById("result");
const status = document.getElementById("status");
const copyBtn = document.getElementById("copyBtn");

function updateForm() {
  const value = task.value;
  extraFields.innerHTML = "";

  if (value === "qa") {
    inputLabel.textContent = "Your question";
    input.placeholder = "Example: Which is the largest ocean?";
  } else if (value === "explain") {
    inputLabel.textContent = "Topic to explain";
    input.placeholder = "Example: Explain photosynthesis";
  } else if (value === "quiz") {
    inputLabel.textContent = "Passage or topic";
    input.placeholder = "Paste study material or enter a topic...";
    extraFields.innerHTML = `
      <label for="count">Number of questions</label>
      <input id="count" type="number" min="1" max="10" value="3">
    `;
  } else if (value === "summarize") {
    inputLabel.textContent = "Text to summarize";
    input.placeholder = "Paste your educational passage here...";
  } else {
    inputLabel.textContent = "Learning topic";
    input.placeholder = "Example: SQL";
    extraFields.innerHTML = `
      <label for="level">Learner level</label>
      <select id="level">
        <option value="beginner">Beginner</option>
        <option value="intermediate">Intermediate</option>
        <option value="advanced">Advanced</option>
      </select>
    `;
  }
}

task.addEventListener("change", updateForm);
updateForm();

function escapeHtml(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderQuiz(items) {
  return items.map((q, index) => {
    const options = q.options.map(opt =>
      `<div class="option"><strong>${escapeHtml(opt)}</strong></div>`
    ).join("");
    return `
      <article class="quiz-question">
        <h3>${index + 1}. ${escapeHtml(q.question)}</h3>
        ${options}
        <p><strong>Correct answer:</strong> ${escapeHtml(q.correct_answer)}</p>
        <p>${escapeHtml(q.explanation || "")}</p>
      </article>
    `;
  }).join("");
}

async function runTask() {
  const value = task.value;
  const text = input.value.trim();

  if (!text) {
    status.textContent = "Please enter some content first.";
    input.focus();
    return;
  }

  let endpoint;
  let body;

  if (value === "qa") {
    endpoint = "/qa";
    body = { text };
  } else if (value === "explain") {
    endpoint = "/explain";
    body = { text };
  } else if (value === "quiz") {
    endpoint = "/quiz";
    body = { text, count: Number(document.getElementById("count").value) || 3 };
  } else if (value === "summarize") {
    endpoint = "/summarize";
    body = { text };
  } else {
    endpoint = "/learn/recommendations";
    body = {
      topic: text,
      level: document.getElementById("level").value
    };
  }

  submitBtn.disabled = true;
  status.textContent = "Generating...";
  result.textContent = "";

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "Request failed.");
    }

    if (value === "quiz") {
      result.innerHTML = renderQuiz(data.result);
    } else {
      result.textContent = data.result;
    }

    status.textContent = "Completed.";
  } catch (error) {
    result.textContent = `Error: ${error.message}`;
    status.textContent = "Request failed.";
  } finally {
    submitBtn.disabled = false;
  }
}

submitBtn.addEventListener("click", runTask);

copyBtn.addEventListener("click", async () => {
  const text = result.innerText;
  if (!text) return;
  await navigator.clipboard.writeText(text);
  status.textContent = "Result copied.";
});
