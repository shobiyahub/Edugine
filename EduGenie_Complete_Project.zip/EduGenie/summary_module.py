from ai_service import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational text for quick revision.

Requirements:
- Preserve the important facts and ideas.
- Remove repetition.
- Use short paragraphs or bullet points.
- Do not add information that is not present in the source.

Text:
{text}
"""
    return generate_text(prompt, max_output_tokens=1000)
