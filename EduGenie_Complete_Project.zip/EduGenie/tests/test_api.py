import os
os.environ["MOCK_AI"] = "true"

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_qa():
    response = client.post("/qa", json={"text": "What is Python?"})
    assert response.status_code == 200
    assert "result" in response.json()


def test_explain():
    response = client.post("/explain", json={"text": "Photosynthesis"})
    assert response.status_code == 200
    assert "result" in response.json()


def test_quiz():
    response = client.post("/quiz", json={"text": "Python is a programming language.", "count": 3})
    assert response.status_code == 200
    assert len(response.json()["result"]) == 3


def test_summary():
    response = client.post("/summarize", json={"text": "A short educational paragraph."})
    assert response.status_code == 200
    assert "result" in response.json()


def test_learning_path():
    response = client.post(
        "/learn/recommendations",
        json={"topic": "SQL", "level": "beginner"},
    )
    assert response.status_code == 200
    assert "result" in response.json()
