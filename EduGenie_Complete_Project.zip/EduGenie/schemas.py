from pydantic import BaseModel, Field


class TextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)


class QuizRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)
    count: int = Field(default=3, ge=1, le=10)


class LearningPathRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=300)
    level: str = Field(default="beginner", max_length=50)
