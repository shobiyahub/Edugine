import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()

# The project document refers to Gemini 1.5 Pro. The SDK/model names evolve,
# so the model is configurable rather than hard-coded into the application.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()

# Set MOCK_AI=true to test the complete UI/backend without a Gemini key.
MOCK_AI = os.getenv("MOCK_AI", "false").lower() in {"1", "true", "yes"}

# Optional local explanation model. Disabled by default because it requires
# the heavier transformers/torch stack.
USE_LOCAL_EXPLAINER = os.getenv("USE_LOCAL_EXPLAINER", "false").lower() in {"1", "true", "yes"}
LOCAL_EXPLAINER_MODEL = os.getenv(
    "LOCAL_EXPLAINER_MODEL",
    "MBZUAI/LaMini-Flan-T5-783M"
).strip()
