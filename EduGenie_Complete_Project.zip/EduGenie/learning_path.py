from ai_service import generate_text


def get_learning_recommendations(topic: str, level: str = "beginner") -> str:
    prompt = f"""
Create a personalized learning path for: {topic}
Learner level: {level}

Include:
1. Learning goal
2. Beginner fundamentals
3. Intermediate concepts
4. Advanced concepts
5. A practical mini-project
6. A suggested weekly timeline
7. Useful resource types such as documentation, videos, articles or books

Make the sequence realistic and easy to follow. Clearly separate each stage.
"""
    return generate_text(prompt, max_output_tokens=1600)
