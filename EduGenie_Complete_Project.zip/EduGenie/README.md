# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI web application based on the supplied project document. It provides:

- Question answering
- Beginner-friendly topic explanation
- MCQ quiz generation
- Text summarization
- Personalized learning paths

## Architecture

```text
Browser
  |
  v
FastAPI (main.py)
  |
  +-- /qa ----------------------> qna.py
  +-- /explain -----------------> explanation_module.py
  +-- /quiz --------------------> quiz_module.py
  +-- /summarize ---------------> summary_module.py
  +-- /learn/recommendations ---> learning_path.py
                                      |
                                      v
                                ai_service.py
                                      |
                                      v
                              Google Gemini API
```

The frontend is plain HTML/CSS/JavaScript and is served by FastAPI.

## Requirements

- Python 3.10+
- Gemini API key for real AI mode
- VS Code recommended

The application also has `MOCK_AI=true` for testing without an API key.

## Windows / VS Code setup

Open the project folder in VS Code and open Terminal.

### 1. Create virtual environment

```powershell
python -m venv .venv
```

### 2. Activate it

```powershell
.venv\Scripts\activate
```

### 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure environment

Copy `.env.example` to `.env`.

For a no-key smoke test:

```env
MOCK_AI=true
```

For real Gemini:

```env
GEMINI_API_KEY=your_real_key
MOCK_AI=false
```

### 5. Start the server

```powershell
uvicorn main:app --reload --port 8000
```

Open:

http://127.0.0.1:8000

API documentation:

http://127.0.0.1:8000/docs

## Testing

### Browser test

Try each task:

1. Q&A: `Which is the largest ocean?`
2. Explain: `Photosynthesis`
3. Quiz: paste a paragraph and generate 3 questions.
4. Summarize: paste a long paragraph.
5. Learning path: `SQL`, level `beginner`.

### API smoke test

Health:

```powershell
curl http://127.0.0.1:8000/health
```

Q&A:

```powershell
curl -X POST http://127.0.0.1:8000/qa `
  -H "Content-Type: application/json" `
  -d "{\"text\":\"What is the largest ocean?\"}"
```

## Optional local LaMini explanation model

The supplied document describes `LaMini-Flan-T5-783M` for concept explanation. This implementation keeps that model optional so the base application remains lightweight.

Install:

```powershell
pip install -r requirements-local.txt
```

Then in `.env`:

```env
USE_LOCAL_EXPLAINER=true
```

If the local model cannot load, EduGenie automatically falls back to Gemini.

## Project files

- `main.py` — FastAPI app and REST endpoints
- `config.py` — environment configuration
- `ai_service.py` — Gemini client and mock mode
- `qna.py` — Q&A
- `explanation_module.py` — explanation
- `quiz_module.py` — quiz generation
- `summary_module.py` — summarization
- `learning_path.py` — learning recommendations
- `schemas.py` — request validation
- `templates/index.html` — frontend
- `static/style.css` — styling
- `static/app.js` — frontend/backend integration
- `requirements.txt` — core dependencies
- `requirements-local.txt` — optional local-model dependencies

## Important

Never commit `.env` or your Gemini API key to GitHub. `.env` is already included in `.gitignore`.
