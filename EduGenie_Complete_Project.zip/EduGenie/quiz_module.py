from ai_service import generate_json


QUIZ_SCHEMA = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "question": {"type": "string"},
            "options": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 4,
                "maxItems": 4,
            },
            "correct_answer": {"type": "string"},
            "explanation": {"type": "string"},
        },
        "required": ["question", "options", "correct_answer", "explanation"],
    },
}


def generate_quiz(passage: str, count: int = 3):
    prompt = f"""
Create exactly {count} multiple-choice questions from the passage below.

Rules:
- Each question must have exactly four options.
- correct_answer must exactly match one option.
- Add a short explanation for the correct answer.
- Questions must test the supplied passage, not unrelated knowledge.
- Return only the requested JSON array.

Passage:
{passage}
"""
    result = generate_json(prompt, QUIZ_SCHEMA)
    return result[:count]
